# Genesis OS Phase 1 Registry Export + Threshold Pack

This package freezes the machine-readable code-table exports and threshold/config values required by the Phase 1 build packet.

## What is included
- `registry/` — code tables, enums, labels, catalog IDs, Missing Layers vocabularies, Sanctuary module/state registry, and Human Emotion Genome family registry.
- `thresholds/` — Readiness/Forecast mechanics, DriftEligibility gates, Batch 1 cluster constants, policy caps, observational windows, and unresolved freeze points.
- `combined_registry_threshold_pack.phase1.v1.json` — one-file combined export for codegen tools.
- `manifest.json` — pack metadata and precedence.

## What is intentionally *not* included
- Workbook-owned compatibility score law as a replacement formula.
- Import scripts or seed loaders.
- MatchHarness fixtures.
- Copy library pack.
- Migration ledger.
- Any constant that the source documents referenced but did not numerically freeze.

## Important rule
If the workbook and this pack disagree, the workbook wins.

## Suggested use order
1. Load `registry/` files into code-adjacent configuration or database-backed registries.
2. Load `thresholds/` files into the policy/config layer.
3. Wire workbook import scripts against these registries.
4. Run MatchHarness parity before turning on any user-facing cluster/readiness/forecast surfaces.
5. Resolve `thresholds/unresolved_freeze_points.phase1.v1.json` before claiming the build is zero-guess.

